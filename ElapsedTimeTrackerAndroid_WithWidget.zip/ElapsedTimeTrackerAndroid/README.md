# Elapsed Time Tracker — Custom Android App + Home-screen Widget

Features:
- Choose a custom start date and time.
- The selection is saved on the phone and restored when the app is reopened.
- Live elapsed-time counter in the app.
- Home-screen widget with elapsed days and a seconds-updating Android Chronometer.
- Tap the widget to open the app.
- Reset to the default start time: 6 October 2026, 3:46 PM.
- Works offline.

## Build APK
This is the Android Studio source project, not an installable APK. Android build tools are not available in this environment to compile it.

1. Install Android Studio on a computer.
2. Extract this ZIP and open the `ElapsedTimeTrackerAndroid` folder.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Transfer `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it.

## Add the widget on Realme
After installing the APK:
1. Long-press an empty area of the home screen (or pinch inward with two fingers).
2. Tap **Widgets** or the **+** button.
3. Find **Elapsed Time Tracker**.
4. Touch and hold its widget and drag it onto the home screen.

Widget updates its chronometer every second through Android's built-in Chronometer. The displayed day count is refreshed on widget updates and when the app changes the saved start time; Android may refresh the widget periodically, so the day count can lag slightly around midnight.
