package com.harry.elapsedtimetracker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class ElapsedTimerWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (id in appWidgetIds) updateOne(context, appWidgetManager, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, ElapsedTimerWidgetProvider::class.java))
            for (id in ids) updateOne(context, manager, id)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.harry.elapsedtimetracker.REFRESH_WIDGET"
        private const val PREFS = "elapsed_timer_settings"
        private const val START_KEY = "saved_start_millis"
        private const val DEFAULT_START = 1791281760000L

        fun refresh(context: Context) {
            val intent = Intent(context, ElapsedTimerWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val start = prefs.getLong(START_KEY, DEFAULT_START)
            val now = System.currentTimeMillis()
            val elapsedMillis = (now - start).coerceAtLeast(0L)
            val totalSeconds = elapsedMillis / 1000L
            val days = totalSeconds / 86400L
            val elapsedSinceMidnight = totalSeconds % 86400L

            val views = RemoteViews(context.packageName, R.layout.elapsed_timer_widget)
            views.setTextViewText(R.id.widgetDays, "${days}d elapsed")
            views.setTextViewText(R.id.widgetStart, "Since " + SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH).apply {
                timeZone = TimeZone.getDefault()
            }.format(Date(start)))

            // Chronometer runs on Android's monotonic clock and ticks every second without
            // a repeating background alarm. The base is recalculated from the saved wall time.
            val base = SystemClock.elapsedRealtime() - elapsedSinceMidnight * 1000L
            views.setChronometer(R.id.widgetChronometer, base, "%s", true)

            val openIntent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
