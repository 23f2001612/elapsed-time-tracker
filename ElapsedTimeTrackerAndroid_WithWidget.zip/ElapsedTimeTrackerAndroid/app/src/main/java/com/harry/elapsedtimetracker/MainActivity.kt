package com.harry.elapsedtimetracker

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : Activity() {
    private val prefsName = "elapsed_timer_settings"
    private val startKey = "saved_start_millis"
    private val defaultStartMillis = parseDefaultStart()
    private var startMillis: Long = defaultStartMillis

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var startLabel: TextView
    private lateinit var daysView: TextView
    private lateinit var hoursView: TextView
    private lateinit var minutesView: TextView
    private lateinit var secondsView: TextView
    private lateinit var totalHoursView: TextView
    private lateinit var totalMinutesView: TextView
    private lateinit var totalSecondsView: TextView

    private val tick = object : Runnable {
        override fun run() {
            updateTimer()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startMillis = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .getLong(startKey, defaultStartMillis)
        window.statusBarColor = Color.rgb(11, 16, 32)
        window.navigationBarColor = Color.rgb(11, 16, 32)
        buildScreen()
        updateTimer()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    private fun buildScreen() {
        val bg = Color.rgb(11, 16, 32)
        val panel = Color.rgb(21, 29, 49)
        val border = Color.rgb(43, 56, 85)
        val muted = Color.rgb(154, 168, 194)
        val white = Color.rgb(244, 247, 255)
        val yellow = Color.rgb(250, 204, 21)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(24), dp(18), dp(24))
            setBackgroundColor(bg)
        }

        root.addView(label("ELAPSED TIME TRACKER", muted, 12f, true).apply {
            letterSpacing = 0.14f
            gravity = Gravity.CENTER
        }, matchWrap())

        root.addView(label("Time since the start", white, 25f, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(8))
        }, matchWrap())

        startLabel = label("", muted, 14f).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        }
        root.addView(startLabel, matchWrap())

        val timerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        daysView = valueText(white)
        hoursView = valueText(white)
        minutesView = valueText(white)
        secondsView = valueText(yellow)

        val units = listOf(
            daysView to "DAYS",
            hoursView to "HOURS",
            minutesView to "MINUTES",
            secondsView to "SECONDS"
        )
        units.forEachIndexed { index, pair ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(18), dp(3), dp(16))
                background = rounded(panel, border, dp(16))
            }
            card.addView(pair.first, matchWrap())
            card.addView(label(pair.second, muted, 10f, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            }, matchWrap())
            val params = LinearLayout.LayoutParams(0, dp(112), 1f)
            if (index > 0) params.leftMargin = dp(6)
            timerRow.addView(card, params)
        }
        root.addView(timerRow, matchWrap())

        val totals = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = rounded(panel, border, dp(16))
        }
        totalHoursView = addTotal(totals, "Total hours", muted, white)
        totalMinutesView = addTotal(totals, "Total minutes", muted, white)
        totalSecondsView = addTotal(totals, "Total seconds", muted, white)
        val totalsParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        totalsParams.topMargin = dp(16)
        root.addView(totals, totalsParams)

        val changeButton = Button(this).apply {
            text = "Change start date & time"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.rgb(11, 16, 32))
            background = rounded(yellow, yellow, dp(14))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { chooseDateAndTime() }
        }
        val buttonParams = matchWrap()
        buttonParams.topMargin = dp(16)
        root.addView(changeButton, buttonParams)

        val resetButton = Button(this).apply {
            text = "Reset to 6 October 2026, 3:46 PM"
            isAllCaps = false
            textSize = 13f
            setTextColor(muted)
            background = rounded(bg, border, dp(14))
            setOnClickListener {
                startMillis = defaultStartMillis
                saveStart()
                updateTimer()
                ElapsedTimerWidgetProvider.refresh(this)
            }
        }
        val resetParams = matchWrap()
        resetParams.topMargin = dp(8)
        root.addView(resetButton, resetParams)

        root.addView(label(
            "Your selected start time is saved on this phone. Close and reopen the app anytime; the counter will catch up automatically.",
            muted, 12f
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(14), dp(8), 0)
        }, matchWrap())

        setContentView(root)
    }

    private fun chooseDateAndTime() {
        val cal = Calendar.getInstance().apply { timeInMillis = startMillis }
        DatePickerDialog(
            this,
            { _, year, month, day ->
                val selected = Calendar.getInstance().apply {
                    timeInMillis = startMillis
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, day)
                }
                TimePickerDialog(
                    this,
                    { _, hour, minute ->
                        selected.set(Calendar.HOUR_OF_DAY, hour)
                        selected.set(Calendar.MINUTE, minute)
                        selected.set(Calendar.SECOND, 0)
                        selected.set(Calendar.MILLISECOND, 0)
                        startMillis = selected.timeInMillis
                        saveStart()
                        updateTimer()
                        ElapsedTimerWidgetProvider.refresh(this)
                    },
                    cal.get(Calendar.HOUR_OF_DAY),
                    cal.get(Calendar.MINUTE),
                    true
                ).show()
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun saveStart() {
        getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            .edit()
            .putLong(startKey, startMillis)
            .apply()
    }

    private fun updateTimer() {
        val total = ((System.currentTimeMillis() - startMillis) / 1000L).coerceAtLeast(0L)
        val days = total / 86400L
        val hours = (total % 86400L) / 3600L
        val minutes = (total % 3600L) / 60L
        val seconds = total % 60L

        daysView.text = String.format(Locale.US, "%03d", days)
        hoursView.text = String.format(Locale.US, "%02d", hours)
        minutesView.text = String.format(Locale.US, "%02d", minutes)
        secondsView.text = String.format(Locale.US, "%02d", seconds)

        val dateFormat = SimpleDateFormat("d MMM yyyy, h:mm:ss a", Locale.ENGLISH)
        dateFormat.timeZone = TimeZone.getDefault()
        startLabel.text = "STARTED ${dateFormat.format(Date(startMillis))}"

        totalHoursView.text = String.format(Locale.US, "%,.2f h", total / 3600.0)
        totalMinutesView.text = "${fmt(total / 60L)} min"
        totalSecondsView.text = "${fmt(total)} s"
    }

    private fun addTotal(parent: LinearLayout, title: String, muted: Int, white: Int): TextView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(title, muted, 14f), LinearLayout.LayoutParams(0, -2, 1f))
        val value = label("—", white, 14f, true).apply { gravity = Gravity.END }
        row.addView(value, wrap())
        parent.addView(row, matchWrap())
        return value
    }

    private fun fmt(value: Long): String =
        java.text.NumberFormat.getIntegerInstance(Locale("en", "IN")).format(value)

    private fun label(text: String, color: Int, size: Float, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun valueText(color: Int) = label("00", color, 25f, true).apply {
        gravity = Gravity.CENTER
        includeFontPadding = false
    }

    private fun rounded(fill: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun wrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun parseDefaultStart(): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, 2026)
            set(Calendar.MONTH, Calendar.OCTOBER)
            set(Calendar.DAY_OF_MONTH, 6)
            set(Calendar.HOUR_OF_DAY, 15)
            set(Calendar.MINUTE, 46)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }
}
